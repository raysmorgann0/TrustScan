Open the TrustScan file.
After the necessary modules are installed and you connect to the server, you will need to enter the wallet address you need.
TrustScan will select the necessary seed phrase, you need to load a database of different words, the more words, the greater the chance that everything will be successful.
I will be glad to receive your feedback.